jQuery(document).ready(function($){
    console.log('jQuery version: ' + jQuery.fn.jquery); // version
    console.log('jQuery version (aliased): ' + $.fn.jquery); // version, alias confirmation

    var win = $(window),
        body = $(document.body);

    // body events and manipulation
    body
	    .on('click', 'a[rel~="external"]', function(e){
	        // rel="external" opens in new window
	        e.preventDefault();
	        window.open(this.href);
	        return false;
	    })
		.on('click', '.dropdown-toggle', function(e) {
			// bootstrap fix
	    	e.preventDefault();
	        window.location.href = this.href;
	        return false;
	    })
	    .on('change', '#filter_on_change', function() {
	        // reload with filter querystring
	        window.location = $('#filter_on_change_url').val() + '?filter=' + $(this).val();
	    });

    // initialize tooltips
    $('[data-toggle="tooltip"]').tooltip();

    // search button
    $( '.search-icon' ).click(function(e){
        $( '#search' ).fadeToggle();
    });

    // search button
    $( '.search-close' ).click(function(e){
        $( '#search' ).fadeToggle();
    });

    //inforgraphic fade in
    $(document).ready(function() {
        /* Every time the window is scrolled ... */
        $(window).scroll( function(){
            /* Check the location of each desired element */
            $('.infographic-image').each( function(i){
                var bottom_of_object = $(this).offset().top + $(this).outerHeight();
                var bottom_of_window = $(window).scrollTop() + $(window).height();

                /* If the object is completely visible in the window, fade it it */
                if( bottom_of_window > bottom_of_object ){

                    $(this).animate({'opacity':'1'},1000);
                }
            });
        });
    });

    // accordion
    function doAccordion() {
      // make sure all content shows by default if JS not enabled
  		$('.accordion--title').removeClass('toggle-open');
  		$('div.accordion--content').removeClass('toggle-open');
  		$('.accordion--title').attr('aria-selected', "false");

  		$('.accordion--title').click(function(){
  			var tab_id = $(this).attr('data-tab');

            if ($(this).hasClass('toggle-open')) {
                $(this).removeClass('toggle-open');
        		$(this).attr('aria-selected', "false");
        		$(this).siblings("#"+tab_id).removeClass('toggle-open');
            } else {
                $(this).addClass('toggle-open');
        		$(this).attr('aria-selected', "true");
        		$(this).siblings("#"+tab_id).addClass('toggle-open');
            }
  		});
    }
     // accordion on facet load
    // $(document).on('facetwp-loaded', function(){
    //     doAccordion();
    // });


    // accordion
    function doAccordionNoFacets() {
        // make sure all content shows by default if JS not enabled
  		$('.accordion--title').removeClass('toggle-open');
  		$('div.accordion--content').removeClass('toggle-open');
  		$('.accordion--title').attr('aria-selected', "false");

  		$('.accordion--title').click(function(){
              var tab_id = $(this).attr('data-tab');

            if ( $(this).hasClass('toggle-open') ) {
                $(this).removeClass('toggle-open');
        		$(this).attr('aria-selected', "false");
        		$(this).siblings('#'+tab_id).removeClass('toggle-open');
            } else {
                $(this).addClass('toggle-open');
        		$(this).attr('aria-selected', "true");
        		$(this).siblings('#'+tab_id).addClass('toggle-open');
            }
  		});
    }

    // call accordion if facets don't exist. 
   $(document).ready(function(){   
        if ( !$('.facetwp.facetwp-template').length ) {
            doAccordionNoFacets();
        } 
   });

   // call accordion if facets exist. 
   $(document).on('facetwp-loaded', function(){
        doAccordion();
    });

    //add/remove nav-open class to body for off-canvas nav
    $('.toggle-nav').click(function() {
        $('body').toggleClass("nav-open");
    });


    // carousel
    $('.owl-carousel').owlCarousel({
        center: true,
        items:1.2,
        nav:true,
        loop:true,
        margin:30,
        responsive:{
            600:{
                items:2
            }
        }
    });

    //to top on mobile
    (function() {

        var totop = $('#to-top');

        setInterval(function() {
            win.scroll(function() { scrolling = true; });
            if(typeof scrolling !== 'undefined' && scrolling) {
                scrolling = false;
                if(win.scrollTop() > 250) {
                    totop.fadeIn();
                } else {
                    totop.fadeOut();
                }
            }
        }, 250);

        totop.hide().on('click', function(event) {
            $('html,body').animate({scrollTop: 0}, 1000, 'easeOutQuart');
            event.preventDefault();
            return false;
        });

    })();

    //replace images with retina images, if available
    var $images = $("img[data-1x]");

        if (window.devicePixelRatio == 2) {
          $.each($images, function() {
            var $this = $(this);

            $this.attr("src", $this.data("2x"));
          });
        } else {
          $.each($images, function() {
            var $this = $(this);

            $this.attr("src", $this.data("1x"));
        });
    }



    // Recent posts hover class
    $('.home-recent__thumb-wrap, .home-recent__title').hover(
        function(){
            $(this).closest('.home-recent__item').addClass('home-recent__item--active');
        }, function(){
            $(this).closest('.home-recent__item').removeClass('home-recent__item--active');
        }
    );



    // Home Customers Fader
    (function() {
        var items = $('.customer__link');
        var itemIndex = -1;

        function showNextItem() {
            ++itemIndex;
            items.eq(itemIndex % items.length)
                .fadeIn(800)
                .delay(4000)
                .fadeOut(800, showNextItem);
        }

        showNextItem();

    })();


    // ======================================================================
    // Fitvids
    // ======================================================================
    $(".content").fitVids();

/*
    var owl = $('.logo-grid');
    owl.owlCarousel({
        items: 6,
        loop: true,
        autoplay: true,
        autoplayTimeout: 1500,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            375: {
                items: 2
            },
            768: {
                items: 4
            },
            1024: {
                items: 5
            },
            1300: {
                items: 6
            }
        }
    });
	
*/
});

// SETS MIN-HEIGHT TO HIGHEST NUMBER OUT OF ALL EVENTS ON EVENTS PAGE FOR DISPLAY CONSISTENCY
let eventsImages = document.querySelectorAll('.events .event img');
let eventsImagesHeights = [];

if (eventsImages) {
    eventsImages.forEach((img) => {
        eventsImagesHeights.push(img.height);
    });
    
    let largestImageHeight = Math.max(...eventsImagesHeights);
    
    eventsImages.forEach((img) => {
        img.style.minHeight = largestImageHeight + 'px';
    });
};


/*
    ====================================================
     UI/UX RESOURCE LIBRARY
    ====================================================
*/

resourceLibSwitch()

function resourceLibSwitch() {
    
    let resourceLibSwitch = document.querySelector('.resource-lib-view-mode .switch')
    let resourceTypeFilter = document.querySelector('[data-name="resource_type"]')

    if (resourceLibSwitch) {
        resourceLibSwitch.addEventListener('click', () => {
            resourceLibSwitch.classList.toggle('active')
        
            let url = new URL(window.location)
            url.searchParams.set('view_by_update', 'true')
            window.history.pushState({}, '', url)
        
            if (resourceLibSwitch.classList.contains('active')) {
                resourceTypeFilter.style.display = 'none'
                url.searchParams.set('view_by_update', 'true')
                window.history.pushState({}, '', url)
            } else {
                resourceTypeFilter.style.display = ''
                url.searchParams.delete('view_by_update')
                window.history.pushState({}, '', url)
            }
        
            FWP.reset()
        })
    }
}


/*
    ====================================================
     LOGO CAROUSEL
    ====================================================
*/

logoCarousel()

function logoCarousel() {

    if (document.querySelector('.logo-grid__slide-container')) {
    
        let logoSlider = document.querySelector('.logo-grid__slide-container')
        let numOfLogos = logoSlider.querySelectorAll('img').length
        let logoSliderCopy = logoSlider.cloneNode(true)
        logoSlider.insertAdjacentElement('afterend', logoSliderCopy)
    
        let sliders = [logoSlider, logoSliderCopy]
    
        sliders.forEach(slider => {
            slider.style.animationDuration = `${numOfLogos * 2.5}s`
            slider.style.animationName = 'logoGrid'
        })
    }
}

/*
    ====================================================
     RESOURCES PAGE 
    ====================================================
*/

if (document.querySelectorAll('.resources-dropdown')) {

    let resourcesDropdowns = document.querySelectorAll('.resources-dropdown')
    
    resourcesDropdowns.forEach(res => {
        res.querySelector('button').addEventListener('click', () => {            
            res.querySelector('.resources-dropdown-items').classList.toggle('active')
            res.querySelector('button').classList.toggle('active')
        })
    })

    let listDropdowns = document.querySelectorAll('.resources-dropdown .has-submenu')

    listDropdowns.forEach(li => {
        li.querySelector('a').addEventListener('click', (e) => {
            e.preventDefault()
            li.classList.toggle('active')
        })
    })
}

/*
    ====================================================
     ECOSYSTEM RESOURCES DROPDOWN
    ====================================================
*/

ecosystemResources()

function ecosystemResources() {

    var lists = document.querySelectorAll('.ecosystem-features-resources')
    
    if (lists.length > 0) {
    
        lists.forEach((list) => {
            var btn = list.querySelector('button')
            var resources = list.querySelector('.ecosystem-features-resources-list')
            var resourcesHeight = resources.scrollHeight
        
            btn.addEventListener('click', () => {
        
                list.classList.toggle('active')
        
                toggleFaq(list, resources, resourcesHeight)
            })
        })
        
        function toggleFaq(list, resources, resourcesHeight) {
            if (list.classList.contains('active')) {
                resources.style.height = resourcesHeight + 'px'
            } else {
                resources.style.height = ''
            }
        }
    }
}


/*
    ====================================================
     ACCORDIONS
    ====================================================
*/

window.addEventListener('facetwp-loaded', accdnList)

function accdnList() {

    var accdns = document.querySelectorAll('.accdn-list .accdn-single')
    
    if (accdns.length > 0) {
    
        accdns.forEach((accdn, idx) => {
            var accdnTitle = accdn.querySelector('.accdn-title')
            var accdnContent = accdn.querySelector('.accdn-content')
            var accdnContentHeight = accdnContent.scrollHeight

            if (idx == 0) {
                accdn.classList.add('active')
        
                toggleAccdn(accdn, accdnContent, accdnContentHeight)
            }

            if (!accdnTitle.getAttribute('has-listener')) {

                accdnTitle.addEventListener('click', () => {
                    
                    accdn.classList.toggle('active')
                    
                    toggleAccdn(accdn, accdnContent, accdnContentHeight)
                })

                accdnTitle.setAttribute('has-listener', true) // to prevent duplication of click event
            }
        })
        
        function toggleAccdn(accdn, accdnContent, accdnContentHeight) {
            if (accdn.classList.contains('active')) {
                accdnContent.style.marginBottom = 20 + 'px'
                accdnContent.style.height = accdnContentHeight + 'px'
            } else {
                accdnContent.style.height = ''
                accdnContent.style.marginBottom = ''
            }
        }
    }
}


resultsLoadingAnimation()

function resultsLoadingAnimation() {
    if (document.querySelector('.solutions-ecosystem__cards')) {
        let resultsContainer = document.querySelector('.solutions-ecosystem__cards');
    
        document.addEventListener('facetwp-refresh', () => {
            resultsContainer.classList.add('loading')
        })
        
        document.addEventListener('facetwp-loaded', () => {
            resultsContainer.classList.remove('loading')
        })
    }
}
