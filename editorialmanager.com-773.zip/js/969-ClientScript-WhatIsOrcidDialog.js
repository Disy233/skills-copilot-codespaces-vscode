﻿/*----------------------------------------------------------------------------
 * Copyright © 2014-Present Aries Systems Corporation. All Rights Reserved.
 * Copying, reverse engineering, adaptation or any other derivative use
 * prohibited.  This material is proprietary and confidential information
 * of Aries Systems Corporation.
 *
 * Date Created: 20141215
 * Version Introduced: 12.0
 * Spec #: 12.0-34
 * Depends:
 *   jquery.js
 *	 jquery.ui.js
 * --------------------------------------------------------------------------*/

// summary: 
// The javascript function, showWhatIsOrcidDialog, is used to display a modal dialog showing the content of divWhatIsOrcid (a DIV) from WhatIsORCID.aspx.

function showWhatIsOrcidDialog(journalCode)
{
    var href = window.location.href.toLowerCase(); 
    var length = href.indexOf(journalCode.toLowerCase()) + journalCode.length;

    href = href.substr(0, length);
    href = href + "/WhatIsORCID.aspx? #divWhatIsOrcid";

    $('<div id=DialogDiv>').dialog({
        modal: true, 
        open: function () {
            $(this).load(href);
        },
        close: function (e) {
            $(this).empty();
            $(this).dialog('destroy');
        },
        height: 250,
        width: 500,
        buttons: {
            Close: function () { $(this).dialog("close"); }
        },
        resizable: false
    });

    $("#DialogDiv").siblings(".ui-dialog-titlebar").hide();
} 