﻿/*----------------------------------------------------------------------------
 * Copyright © 2024-Present Aries Systems Corporation. All Rights Reserved.
 * Copying, reverse engineering, adaptation or any other derivative use
 * prohibited.  This material is proprietary and confidential information
 * of Aries Systems Corporation.
 *
 * Date Created: 20240919 AS
 * Version Introduced: 17.0
 * Spec #: EMPM-1911
 * Depends:
 *   jquery.js
 *	 jquery.ui.js
 * --------------------------------------------------------------------------*/

// summary: 
// The javascript function, showAboutIdentityDialog, is used to display a modal dialog showing the content of divAboutIdentity (a DIV) from AboutIdentity.aspx.

function showAboutIdentityDialog(journalCode)
{
    var href = window.location.href.toLowerCase(); 
    var length = href.indexOf(journalCode.toLowerCase()) + journalCode.length;

    href = href.substr(0, length);
    href = href + "/AboutIdentity.aspx? #divAboutIdentity";

    $('<div id=DialogDiv>').dialog({
        modal: true, 
        open: function () {
            $(this).load(href);
        },
        close: function (e) {
            $(this).empty();
            $(this).dialog('destroy');
        },
        height: 250,
        width: 500,
        buttons: {
            Close: function () { $(this).dialog("close"); }
        },
        resizable: false
    });

    $("#DialogDiv").siblings(".ui-dialog-titlebar").hide();
} 
